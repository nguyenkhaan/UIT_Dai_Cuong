#pragma once 
#include "NhanVien.hpp"
#include "Tour.hpp"
using namespace std; 
class Company {
protected:
    int n, m;
    vector<Tour*> a;
    vector<NhanVien*> b;
    int msthue;
    string name, address;
    map<int, HuongDanVien*> map_hdv;
public:
    void companyInputInfo() {
        cout << "NHAP THONG TIN CONG TY:\n";
        cout << "Nhap ma so thue: "; cin >> msthue; cin.ignore();
        cout << "Nhap ten cong ty: "; getline(cin, name);
        cout << "Nhap dia chi: "; getline(cin, address);
    }

    void companyInputTour() {
        cout << "\nNHAP DANH SACH TOUR:\n";
        cout << "Nhap so luong tour: "; cin >> n;
        for (int i = 0; i < n; ++i) {
            int type;
            cout << "Tour thu " << i + 1 << ", loai tour (1.Trong nuoc, 2.Ngoai nuoc): ";
            cin >> type;
            Tour *t = NULL; 
            if (type == 1) t = new TrongNuoc; 
            else t = new NgoaiNuoc; 
           // Tour* t = ((type == 1)? new TrongNuoc : new NgoaiNuoc); 
            t->inputTour();
            a.push_back(t);
        }
    }

    void companyInputNhanVien() {
        cout << "\nNHAP DANH SACH NHAN VIEN:\n";
        cout << "Nhap so luong nhan vien: "; cin >> m;
        for (int i = 0; i < m; ++i) {
            int type;
            cout << "Nhan vien thu " << i + 1 << ", loai (1.Van phong, 2.Huong dan vien): ";
            cin >> type;
            NhanVien* nv = (type == 1) ? static_cast<NhanVien*>(new VanPhong()) : new HuongDanVien();
            nv->inputNhanVien();
            b.push_back(nv);
        }
    }

    void companyOutputInfo() {
        cout << "\nTHONG TIN CONG TY:\n";
        cout << "Ma so thue: " << msthue << "\n";
        cout << "Ten cong ty: " << name << "\n";
        cout << "Dia chi: " << address << "\n";
    }

    void companyOutputTour() {
        cout << "\nDANH SACH TOUR:\n";
        for (int i = 0; i < a.size(); ++i) {
            cout << "\nTour thu " << i + 1 << ":\n";
            a[i]->outputTour();
        }
    }

    void companyOutputNhanVien() {
        cout << "\nDANH SACH NHAN VIEN:\n";
        for (int i = 0; i < b.size(); ++i) {
            cout << "\nNhan vien thu " << i + 1 << ":\n";
            b[i]->outputNhanVien();
        }
    }

    void sortNhanVien() {
        sort(b.begin(), b.end(), [](NhanVien* a, NhanVien* b) {
            return a->getSalary() < b->getSalary();
        });
    }

    void getHDV() {
        for (NhanVien* nv : b) {
            if (HuongDanVien* hdv = dynamic_cast<HuongDanVien*>(nv)) {
                cout << ">>> Ma so HDV: " << nv->getMS() << endl;
                map_hdv[nv->getMS()] = hdv;
            }
        }
    }

    void getTour() {
        for (Tour* t : a) {
            cout << ">>> Ma so tour: " << t->getMS() << endl;
        }
    }
    void outputHDV() 
    {
        for (int i = 0; i < b.size(); ++i) if (dynamic_cast<HuongDanVien*>(b[i])) b[i]->outputNhanVien(); 
        cout << endl; 
    }
    void ganTour() {
        cout << "\nCac huong dan vien hien tai:\n";
        getHDV();
        cout << "\nCac tour hien tai:\n";
        getTour();
        int ms_nv, ms_tour;
        cout << "Nhap ma so nhan vien muon gan tour: "; cin >> ms_nv;
        cout << "Nhap ma so tour muon gan: "; cin >> ms_tour;

        Tour* pTour = nullptr;
        for (Tour* t : a) {
            if (t->getMS() == ms_tour) {
                pTour = t;
                break;
            }
        }

        if (pTour && map_hdv.count(ms_nv)) {
            map_hdv[ms_nv]->addTour(pTour);
            cout << ">>> Gán thành công!\n";
        } else {
            cout << ">>> Ma so khong hop le.\n";
        }
    }

    ~Company() {
        for (Tour* t : a) delete t;
        for (NhanVien* nv : b) delete nv;
    }
};