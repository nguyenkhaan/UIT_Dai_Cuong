#include <bits/stdc++.h>
using namespace std;

class Company;
class Tour;
class NhanVien;
class TrongNuoc;
class NgoaiNuoc;
class VanPhong;
class HuongDanVien;

int digits(int n) {
    int d = 0;   //Tu cai them ham tinh so luong chu so 
    while (n) {
        ++d;
        n /= 10;
    }
    return d;
}

class NhanVien {
protected:
    int ms;
    string name;
    string address;
    string phone;
    double salary;
public:
    virtual void inputNhanVien() {
        cout << "Nhap ma so (so nguyen): "; cin >> ms;
        cin.ignore();
        cout << "Nhap ho va ten: "; getline(cin, name);
        cout << "Nhap dia chi: "; getline(cin, address);
        cout << "Nhap so dien thoai: "; cin >> phone;
    }

    virtual void outputNhanVien() {
        cout << "\nMa so nhan vien: " << ms;
        cout << "\nHo va ten: " << name;
        cout << "\nDia chi: " << address;
        cout << "\nSo dien thoai: " << phone;
    }

    virtual double getSalary() { return salary; }
    int getMS() { return ms; }
    virtual ~NhanVien() {}
};

class VanPhong : public NhanVien {
protected:
    int ngach;
    int bac;
public:
    void inputNhanVien() override {
        NhanVien::inputNhanVien();
        cout << "Nhap ngach: "; cin >> ngach;
        cout << "Nhap bac: "; cin >> bac;
        salary = getSalary();
    }
    double getSalary() override {
        double k = ngach + bac / pow(10, digits(bac));
        return k * 2.2;
    }
    void outputNhanVien() override {
        NhanVien::outputNhanVien();
        cout << "\nNgach: " << ngach;
        cout << "\nBac: " << bac;
        cout << "\nLuong: " << getSalary() << endl;
    }
};

class Tour {
protected:
    int tourID;
    string name;
    int khach;
    double dongia;
    double huongdan;
public:
    virtual void inputTour() {
        cout << "Nhap ma so tour (So nguyen): "; cin >> tourID;
        cin.ignore();
        cout << "Nhap ten tour: "; getline(cin, name);
        cout << "Nhap so luong khach huong dan: "; cin >> khach;
        cout << "Nhap dong gia moi khach: "; cin >> dongia;
        cout << "Nhap phi huong dan cho tour: "; cin >> huongdan;
    }

    virtual void outputTour() {
        cout << "\nMa so tour: " << tourID;
        cout << "\nTen tour du lich: " << name;
        cout << "\nSo luong khach: " << khach;
        cout << "\nDon gia 1 khach: " << dongia;
        cout << "\nPhi huong dan: " << huongdan;
    }

    int getMS() { return tourID; }
    virtual double getHuongDan() { return huongdan; }

    virtual ~Tour() {}
};

class TrongNuoc : public Tour {
protected:
    string city;
public:
    void inputTour() override {
        Tour::inputTour();
        cout << "Nhap thanh pho tham quan (khong khoang trang): "; cin >> city;
    }

    void outputTour() override {
        Tour::outputTour();
        cout << "\nThanh pho tham quan: " << city << endl;
    }

    double getHuongDan() override { return huongdan; }
};

class NgoaiNuoc : public Tour {
protected:
    string country;
    double hsTour;
public:
    void inputTour() override {
        Tour::inputTour();
        cout << "Nhap quoc gia tham quan (khong khoang trang): "; cin >> country;
        cout << "Nhap he so tour: "; cin >> hsTour;
    }

    void outputTour() override {
        Tour::outputTour();
        cout << "\nQuoc gia tham quan: " << country;
        cout << "\nHe so tour: " << hsTour << endl;
    }

    double getHuongDan() override { return huongdan * hsTour; }
};

class HuongDanVien : public NhanVien {
protected:
    double hardSalary;
    vector<Tour*> tourDan;
public:
    void inputNhanVien() override {
        NhanVien::inputNhanVien();
        cout << "Nhap luong cung: "; cin >> hardSalary;
        int nTours;
        cout << "Nhap so tour da dan: "; cin >> nTours;
        tourDan.clear(); // Khởi tạo rỗng, sẽ gán sau
        salary = 0; // reset lương
    }

    double getSalary() override {
        double ans = hardSalary;
        for (Tour* t : tourDan) {
            ans += t->getHuongDan();
        }
        return ans;
    }

    void outputNhanVien() override {
        NhanVien::outputNhanVien();
        cout << "\nLuong cung: " << hardSalary;
        cout << "\nSo tour da dan: " << tourDan.size();
        cout << "\nTong luong: " << getSalary() << endl;
    }

    void addTour(Tour* t) {
        tourDan.push_back(t);
        salary = getSalary();
    }
};

class Company {
protected:
    int n, m;
    vector<Tour*> a;
    vector<NhanVien*> b;
    int msthue;
    string name, address;
    map<int, HuongDanVien*> map_hdv;
public:
    void companyInputInfo() {
        cout << "NHAP THONG TIN CONG TY:\n";
        cout << "Nhap ma so thue: "; cin >> msthue; cin.ignore();
        cout << "Nhap ten cong ty: "; getline(cin, name);
        cout << "Nhap dia chi: "; getline(cin, address);
    }

    void companyInputTour() {
        cout << "\nNHAP DANH SACH TOUR:\n";
        cout << "Nhap so luong tour: "; cin >> n;
        for (int i = 0; i < n; ++i) {
            int type;
            cout << "Tour thu " << i + 1 << ", loai tour (1.Trong nuoc, 2.Ngoai nuoc): ";
            cin >> type;
            Tour *t = NULL; 
            if (type == 1) t = new TrongNuoc; 
            else t = new NgoaiNuoc; 
           // Tour* t = ((type == 1)? new TrongNuoc : new NgoaiNuoc); 
            t->inputTour();
            a.push_back(t);
        }
    }

    void companyInputNhanVien() {
        cout << "\nNHAP DANH SACH NHAN VIEN:\n";
        cout << "Nhap so luong nhan vien: "; cin >> m;
        for (int i = 0; i < m; ++i) {
            int type;
            cout << "Nhan vien thu " << i + 1 << ", loai (1.Van phong, 2.Huong dan vien): ";
            cin >> type;
            NhanVien* nv = (type == 1) ? static_cast<NhanVien*>(new VanPhong()) : new HuongDanVien();
            nv->inputNhanVien();
            b.push_back(nv);
        }
    }

    void companyOutputInfo() {
        cout << "\nTHONG TIN CONG TY:\n";
        cout << "Ma so thue: " << msthue << "\n";
        cout << "Ten cong ty: " << name << "\n";
        cout << "Dia chi: " << address << "\n";
    }

    void companyOutputTour() {
        cout << "\nDANH SACH TOUR:\n";
        for (int i = 0; i < a.size(); ++i) {
            cout << "\nTour thu " << i + 1 << ":\n";
            a[i]->outputTour();
        }
    }

    void companyOutputNhanVien() {
        cout << "\nDANH SACH NHAN VIEN:\n";
        for (int i = 0; i < b.size(); ++i) {
            cout << "\nNhan vien thu " << i + 1 << ":\n";
            b[i]->outputNhanVien();
        }
    }

    void sortNhanVien() {
        sort(b.begin(), b.end(), [](NhanVien* a, NhanVien* b) {
            return a->getSalary() < b->getSalary();
        });
    }

    void getHDV() {
        for (NhanVien* nv : b) {
            if (HuongDanVien* hdv = dynamic_cast<HuongDanVien*>(nv)) {
                cout << ">>> Ma so HDV: " << nv->getMS() << endl;
                map_hdv[nv->getMS()] = hdv;
            }
        }
    }

    void getTour() {
        for (Tour* t : a) {
            cout << ">>> Ma so tour: " << t->getMS() << endl;
        }
    }
    void outputHDV() 
    {
        for (int i = 0; i < b.size(); ++i) if (dynamic_cast<HuongDanVien*>(b[i])) b[i]->outputNhanVien(); 
        cout << endl; 
    }
    void ganTour() {
        cout << "\nCac huong dan vien hien tai:\n";
        getHDV();
        cout << "\nCac tour hien tai:\n";
        getTour();
        int ms_nv, ms_tour;
        cout << "Nhap ma so nhan vien muon gan tour: "; cin >> ms_nv;
        cout << "Nhap ma so tour muon gan: "; cin >> ms_tour;

        Tour* pTour = nullptr;
        for (Tour* t : a) {
            if (t->getMS() == ms_tour) {
                pTour = t;
                break;
            }
        }

        if (pTour && map_hdv.count(ms_nv)) {
            map_hdv[ms_nv]->addTour(pTour);
            cout << ">>> Gán thành công!\n";
        } else {
            cout << ">>> Ma so khong hop le.\n";
        }
    }

    ~Company() {
        for (Tour* t : a) delete t;
        for (NhanVien* nv : b) delete nv;
    }
};

int main() {
    Company c;
    c.companyInputInfo();         // Nhap thong tin cong ty
    c.companyInputTour();         // Nhap danh sach Tour 
    c.companyInputNhanVien();     // Nhap danh sach nhan vien 

    // Xuat du lieu 
    c.companyOutputInfo();        
    c.companyOutputTour();
    c.companyOutputNhanVien();

    // Sap xep theo luong 
    c.sortNhanVien();
    cout << "\nDANH SACH NHAN VIEN SAU KHI SAP XEP THEO LUONG:\n";
    c.companyOutputNhanVien();
    // Gan tour cho 2 HDV du lich 
    cout << "\nTHUC HIEN GAN TOUR CHO 2 HUONG DAN VIEN DU LICH (HOAC 2 LAN NEU KHONG DU HDV)"; 
    c.ganTour();
    c.ganTour();
    c.sortNhanVien(); //Sap xep lai nhan vien 
    c.outputHDV(); //Xuat ra HDV theo luong 
    return 0;
}
