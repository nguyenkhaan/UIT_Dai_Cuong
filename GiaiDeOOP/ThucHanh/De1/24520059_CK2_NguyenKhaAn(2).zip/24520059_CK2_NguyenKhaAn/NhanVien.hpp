#pragma once 
#include "init.hpp"
using namespace std; 
int digits(int n) {
    int d = 0;   //Tu cai them ham tinh so luong chu so 
    while (n) {
        ++d;
        n /= 10;
    }
    return d;
}

class NhanVien {
protected:
    int ms;
    string name;
    string address;
    string phone;
    double salary;
public:
    virtual void inputNhanVien() {
        cout << "Nhap ma so (so nguyen): "; cin >> ms;
        cin.ignore();
        cout << "Nhap ho va ten: "; getline(cin, name);
        cout << "Nhap dia chi: "; getline(cin, address);
        cout << "Nhap so dien thoai: "; cin >> phone;
    }

    virtual void outputNhanVien() {
        cout << "\nMa so nhan vien: " << ms;
        cout << "\nHo va ten: " << name;
        cout << "\nDia chi: " << address;
        cout << "\nSo dien thoai: " << phone;
    }

    virtual double getSalary() { return salary; }
    int getMS() { return ms; }
    virtual ~NhanVien() {}
};

class VanPhong : public NhanVien {
protected:
    int ngach;
    int bac;
public:
    void inputNhanVien() override {
        NhanVien::inputNhanVien();
        cout << "Nhap ngach: "; cin >> ngach;
        cout << "Nhap bac: "; cin >> bac;
        salary = getSalary();
    }
    double getSalary() override {
        double k = ngach + bac / pow(10, digits(bac));
        return k * 2.2;
    }
    void outputNhanVien() override {
        NhanVien::outputNhanVien();
        cout << "\nNgach: " << ngach;
        cout << "\nBac: " << bac;
        cout << "\nLuong: " << getSalary() << endl;
    }
};