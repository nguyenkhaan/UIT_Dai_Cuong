**main.cpp:** Chương trình đã tách file 

**FileTong/temp2.cpp**: Chương trình tổng, không tách file. Nếu biên dịch main.cpp thất bại thì biên dịch 1 file tổng 