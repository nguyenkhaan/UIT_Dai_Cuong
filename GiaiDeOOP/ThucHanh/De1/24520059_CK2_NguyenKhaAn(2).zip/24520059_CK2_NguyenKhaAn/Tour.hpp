#pragma once
#include "init.hpp"
#include "NhanVien.hpp"
using namespace std; 

class Tour {
protected:
    int tourID;
    string name;
    int khach;
    double dongia;
    double huongdan;
public:
    virtual void inputTour() {
        cout << "Nhap ma so tour (So nguyen): "; cin >> tourID;
        cin.ignore();
        cout << "Nhap ten tour: "; getline(cin, name);
        cout << "Nhap so luong khach huong dan: "; cin >> khach;
        cout << "Nhap dong gia moi khach: "; cin >> dongia;
        cout << "Nhap phi huong dan cho tour: "; cin >> huongdan;
    }

    virtual void outputTour() {
        cout << "\nMa so tour: " << tourID;
        cout << "\nTen tour du lich: " << name;
        cout << "\nSo luong khach: " << khach;
        cout << "\nDon gia 1 khach: " << dongia;
        cout << "\nPhi huong dan: " << huongdan;
    }

    int getMS() { return tourID; }
    virtual double getHuongDan() { return huongdan; }

    virtual ~Tour() {}
};

class TrongNuoc : public Tour {
protected:
    string city;
public:
    void inputTour() override {
        Tour::inputTour();
        cout << "Nhap thanh pho tham quan (khong khoang trang): "; cin >> city;
    }

    void outputTour() override {
        Tour::outputTour();
        cout << "\nThanh pho tham quan: " << city << endl;
    }

    double getHuongDan() override { return huongdan; }
};

class NgoaiNuoc : public Tour {
protected:
    string country;
    double hsTour;
public:
    void inputTour() override {
        Tour::inputTour();
        cout << "Nhap quoc gia tham quan (khong khoang trang): "; cin >> country;
        cout << "Nhap he so tour: "; cin >> hsTour;
    }

    void outputTour() override {
        Tour::outputTour();
        cout << "\nQuoc gia tham quan: " << country;
        cout << "\nHe so tour: " << hsTour << endl;
    }

    double getHuongDan() override { return huongdan * hsTour; }
};

class HuongDanVien : public NhanVien {
protected:
    double hardSalary;
    vector<Tour*> tourDan;
public:
    void inputNhanVien() override {
        NhanVien::inputNhanVien();
        cout << "Nhap luong cung: "; cin >> hardSalary;
        int nTours;
        cout << "Nhap so tour da dan: "; cin >> nTours;
        tourDan.clear(); // Khởi tạo rỗng, sẽ gán sau
        salary = 0; // reset lương
    }

    double getSalary() override {
        double ans = hardSalary;
        for (Tour* t : tourDan) {
            ans += t->getHuongDan();
        }
        return ans;
    }

    void outputNhanVien() override {
        NhanVien::outputNhanVien();
        cout << "\nLuong cung: " << hardSalary;
        cout << "\nSo tour da dan: " << tourDan.size();
        cout << "\nTong luong: " << getSalary() << endl;
    }

    void addTour(Tour* t) {
        tourDan.push_back(t);
        salary = getSalary();
    }
};