#pragma once 
#include <bits/stdc++.h>
using namespace std;

class Company;
class Tour;
class NhanVien;
class TrongNuoc;
class NgoaiNuoc;
class VanPhong;
class HuongDanVien;