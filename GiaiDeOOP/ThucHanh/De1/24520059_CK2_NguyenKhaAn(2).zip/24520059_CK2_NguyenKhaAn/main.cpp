#include "Company.hpp"
using namespace std; 
int main() {
    Company c;
    c.companyInputInfo();         // Nhap thong tin cong ty
    c.companyInputTour();         // Nhap danh sach Tour 
    c.companyInputNhanVien();     // Nhap danh sach nhan vien 

    // Xuat du lieu 
    c.companyOutputInfo();        
    c.companyOutputTour();
    c.companyOutputNhanVien();

    // Sap xep theo luong 
    c.sortNhanVien();
    cout << "\nDANH SACH NHAN VIEN SAU KHI SAP XEP THEO LUONG:\n";
    c.companyOutputNhanVien();
    // Gan tour cho 2 HDV du lich 
    cout << "\nTHUC HIEN GAN TOUR CHO 2 HUONG DAN VIEN DU LICH (HOAC 2 LAN NEU KHONG DU HDV)"; 
    c.ganTour();
    c.ganTour();
    c.sortNhanVien(); //Sap xep lai nhan vien 
    c.outputHDV(); //Xuat ra HDV theo luong 
    return 0;
}
